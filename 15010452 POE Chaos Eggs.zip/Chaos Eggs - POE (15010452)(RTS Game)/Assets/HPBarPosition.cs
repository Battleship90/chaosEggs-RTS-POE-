﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPBarPosition : MonoBehaviour {
    public float distanceY;
    public float distanceZ;
    public Transform owner;
	
	// Update is called once per frame
	void Update () {
        transform.eulerAngles = Camera.main.transform.eulerAngles;
        if(owner != null)
        {
            Vector3 position = new Vector3(owner.position.x, owner.position.y + distanceY, owner.position.z + distanceZ);
            transform.position = position;
        }
	}
}
