﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatingText : MonoBehaviour {
    public string mouni;
    public TextMesh myTextMesh;
	// Use this for initialization
	void Start () {
        myTextMesh.text = mouni;
        myTextMesh.transform.eulerAngles = Camera.main.transform.eulerAngles;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
