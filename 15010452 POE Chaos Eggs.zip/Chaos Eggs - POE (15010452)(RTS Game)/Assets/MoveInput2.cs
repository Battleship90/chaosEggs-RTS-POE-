﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class MoveInput2 : MonoBehaviour {

	public enum SELECTED { Unit, Unit2};
    public SELECTED selectedUnit;

    public Transform unitPointer, unit2Pointer;
    public UnitMovement unitMovement, unit2Movement;
    public float minMoveRange;
    public SpriteRenderer cursor1, cursor2;

    public Text Unit1, Unit2;
    public Engine selectedUnitRoot;

    private void Start()
    {
        GetSelectedUnitRoot();
    }
	// Update is called once per frame
	void Update () {
		if (Input.GetButton("Fire1"))
        {

            if (!EventSystem.current.IsPointerOverGameObject())
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                if(Physics.Raycast(ray, out hit, 100))
                {
                    if(hit.collider.tag == "Terrain")
                    {
                        Debug.DrawLine(ray.origin, hit.point);
                        switch (selectedUnit)
                        {
                            case SELECTED.Unit:
                                MoveToPoint(ref unitPointer, ref cursor1, unitMovement, hit);
                                //unitPointer.position = new Vector3(hit.point.x, unitPointer.position.y, hit.point.z);
                                /*if(Vector3.Distance(unitPointer.position, unitMovement.transform.position) > minMoveRange)
                                {
                                    unitMovement.myRoot.ChangeState(Engine.STATE.Moving);
                                    
                                    cursor1.enabled = true;
                                }*/
                                break;
                            case SELECTED.Unit2:
                                MoveToPoint(ref unit2Pointer, ref cursor2, unit2Movement, hit);
                                break;
                        }
                    }
                }
            }
        }
	}
    public void MoveToPoint(ref Transform pointer, ref SpriteRenderer cursor, UnitMovement unitMove, RaycastHit hitVar)
    {
        pointer.position = new Vector3(hitVar.point.x, pointer.position.y, hitVar.point.z);

        if(Vector3.Distance(pointer.position, unitMove.transform.position) > minMoveRange)
        {
            unitMove.myRoot.ChangeState(Engine.STATE.Moving);
            cursor.enabled = true;
        }
    }
    public void Select()
    {
        selectedUnit = SELECTED.Unit;
        GetSelectedUnitRoot();
        Unit1.color = Color.white;
        Unit2.color = Color.black;
    }
    public void Select2()
    {
        selectedUnit = SELECTED.Unit2;
        GetSelectedUnitRoot();
        Unit1.color = Color.black;
        Unit2.color = Color.white;
    }
    public void Follow1()
    {
        if(selectedUnitRoot.tag != "Unit")
        {
            selectedUnitRoot.ChangeState(Engine.STATE.Following);
            selectedUnitRoot.gameObject.GetComponent<UnitMovement>().unitFollowing = unitMovement.transform;
            Select();
        }
    }

    public void Follow2()
    {
        if (selectedUnitRoot.tag != "Unit2")
        {
            selectedUnitRoot.ChangeState(Engine.STATE.Following);
            selectedUnitRoot.gameObject.GetComponent<UnitMovement>().unitFollowing = unit2Movement.transform;
            Select2();
        }
    }
    public void GetSelectedUnitRoot()
    {
        switch (selectedUnit)
        {
            case SELECTED.Unit:
                selectedUnitRoot = GameObject.FindGameObjectWithTag("Unit").GetComponent<Engine>();
                break;
            case SELECTED.Unit2:
                selectedUnitRoot = GameObject.FindGameObjectWithTag("Unit2").GetComponent<Engine>();
                break;
        }
    }
}
