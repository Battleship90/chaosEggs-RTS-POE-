﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Engine : MonoBehaviour {

    public enum STATE { Idle, Moving, Combat, Following};

    [Header ("State")]
    public STATE currentState;
    public TextMesh myStateText;

    [Header("Stats")]
    public int HP = 60;
    public int def = 5;
    public int atk = 10;
    public int atkVar = 2;
    public float atkSpeed = 2.5f;
    public float reach = 3;

    [Header("Detection")]
    public List<Engine> detected, enemies;

    [Header("Other")]
    public ParticleSystem damageParticle;
    public Slider barHP;
    public GameObject floatingText;
    public float fadeTime = 6;
	// Use this for initialization
	void Start () {
        myStateText = GetComponentInChildren<TextMesh>();
        damageParticle = GetComponentInChildren<ParticleSystem>();
        ChangeState(STATE.Idle);


	}
	
	
	public void ChangeState (STATE state) {
        currentState = state;
        if (myStateText != null) myStateText.text = state.ToString();
	}

    public void TakeDamage(int damage)
    {
        damageParticle.Emit(5);
        int realDamage = damage - def <= 0 ? 1 : damage - def;
        HP = HP - realDamage <= 0 ? 0 : HP - realDamage;
        if (HP <= 0) Destroy(gameObject);

        barHP.gameObject.SetActive(true);
        barHP.value = HP;
        Invoke("FadeLifeBar", fadeTime);


        GameObject displayDamage = Instantiate(floatingText, new Vector3(transform.position.x, transform.position.y + 0.5f, transform.position.z), Quaternion.identity) as GameObject;
        displayDamage.GetComponent<FloatingText>().mouni = realDamage.ToString();

        if (HP <= 0)
        {
            Destroy(gameObject);
        }
    }
    public void FadeLifeBar()
    {
        if(barHP.value == barHP.maxValue)
        {
            barHP.gameObject.SetActive(false);
        }
    }
}

