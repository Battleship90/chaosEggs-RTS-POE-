﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class UnitMovement : MonoBehaviour {

    public bool moving;
    public NavMeshAgent agent;
    public Transform pointer, unitFollowing;
    public float followingDistance;
    public SpriteRenderer pointerSprite;
    public Engine myRoot;


    private void Start()
    {
        myRoot = gameObject.GetComponent<Engine>();
        pointerSprite = pointer.GetComponent<SpriteRenderer>();
    }
        // Update is called once per frame
    void Update () {
        if (myRoot.currentState == Engine.STATE.Moving)
        {
            agent.SetDestination(pointer.position);
            agent.Resume();
        }

        if (myRoot.currentState == Engine.STATE.Following)
        {
            pointer.position = new Vector3(unitFollowing.position.x, pointer.position.y, unitFollowing.position.z);
            pointerSprite.enabled = true;

            if(Vector3.Distance(transform.position, unitFollowing.position) > followingDistance)
            {
                agent.SetDestination(unitFollowing.position);
                agent.Resume();
            }
            else
            {
                agent.Stop();
            }
        }
        if(myRoot.currentState != Engine.STATE.Following && myRoot.currentState != Engine.STATE.Moving)
        {
            pointerSprite.enabled = false;
        }
	}
}
