﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Detect : MonoBehaviour {
    public Engine myRoot;
    // Use this for initialization
    void Start() {
        myRoot = gameObject.GetComponentInParent<Engine>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag != "Terrain" && other.tag != "Untagged")
        {
            myRoot.detected.Add(other.GetComponent<Engine>());
        }
    }

    public void OnTriggerExit(Collider other)
    {
        myRoot.detected.Remove(other.GetComponent<Engine>());
    }
    // Update is called once per frame
    void Update () {
		if(myRoot.enemies.Count > 0)
        {
            myRoot.enemies.Clear();
        }

        foreach (Engine detectedObject in myRoot.detected)
        {
            if(detectedObject == null)
            {
                myRoot.detected.Remove(detectedObject);
            }
            if (detectedObject.tag == "Zombie")
            {
                myRoot.enemies.Add(detectedObject);
            }
        }
        if (myRoot.currentState != Engine.STATE.Moving)
        {
            if(myRoot.enemies.Count > 0)
            {
                myRoot.ChangeState(Engine.STATE.Combat);
            }
            else
            {

                if(myRoot.currentState == Engine.STATE.Combat)
                {
                    myRoot.ChangeState(Engine.STATE.Idle);
                }
            }
        }
	}
}
