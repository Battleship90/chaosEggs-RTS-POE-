﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour {

    public Transform Unit, Unit2;
    public float speed;
    public MoveInput2 moveInput;

    public Texture2D selectionHighlight = null;
    public static Rect selection = new Rect(0, 0, 0, 0);
    private Vector3 startClick = -Vector3.one;

    private static Vector3 moveToDestination = Vector3.zero;
    private static List<string> passables = new List<string>() { "Floor" };//list of strings
                                                                           //passables prevent infinite loops
    public float zoomMaxY = 0;
    public float zoomMinY = 0;
    public float zoomSpeed = 0.05f;
    public float zoomTime = 0.25f;
    public Vector3 zoomDestination = Vector3.zero;

    // Update is called once per frame
    void Update ()
    {
        if (moveInput.selectedUnit == MoveInput2.SELECTED.Unit)
        {
            transform.position = Vector3.Lerp(transform.position, Unit.position, speed * Time.deltaTime);
        }
        if (moveInput.selectedUnit == MoveInput2.SELECTED.Unit2)
        {
            transform.position = Vector3.Lerp(transform.position, Unit2.position, speed * Time.deltaTime);
        }
    CheckCamera();

    Cleanup();
    ZoomCamera();
    }
    private void ZoomCamera()
{
    float moveY = Input.GetAxis("Mouse ScrollWheel");
    if (moveY != 0)
        zoomDestination = transform.position + new Vector3(0, moveY * zoomSpeed, 0);
    if (zoomDestination != Vector3.zero)
    {
        transform.position = Vector3.Lerp(transform.position, zoomDestination, zoomTime);//linearly interpolaters between 2 vectors

        if (transform.position == zoomDestination)
            zoomDestination = Vector3.zero;
    }
    if (transform.position.y > zoomMaxY)
        transform.position = new Vector3(transform.position.x, zoomMaxY, transform.position.z);
    if (transform.position.y < zoomMinY)
        transform.position = new Vector3(transform.position.x, zoomMinY, transform.position.z);
}

private void CheckCamera()
{
    if (Input.GetMouseButtonDown(0))
        startClick = Input.mousePosition;
    else if (Input.GetMouseButtonUp(0))
    {

        startClick = -Vector3.one;
    }
    if (Input.GetMouseButton(0))
        selection = new Rect(startClick.x, InvertMouseY(startClick.y), Input.mousePosition.x - startClick.x, InvertMouseY(Input.mousePosition.y) - (startClick.y));
    if (selection.width < 0)
    {
        selection.x += selection.width;
        selection.width = -selection.width;

    }
    if (selection.height < 0)
    {
        selection.y += selection.height;
        selection.height = -selection.height;
    }
}
private void OnGui()
{
    if (startClick != -Vector3.one)
    {
        GUI.color = new Color(1, 1, 1, 0.5f);
        GUI.DrawTexture(selection, selectionHighlight);
    }
}
public static float InvertMouseY(float y)
{
    return Screen.height - y;
}

private void Cleanup()
{
    if (!Input.GetMouseButtonUp(1))
        moveToDestination = Vector3.zero;
}
public static Vector3 GetDestination()
{
    if (moveToDestination == Vector3.zero)
    {
        RaycastHit hit;
        Ray r = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(r, out hit))
        {
            while (!passables.Contains(hit.transform.gameObject.name))
            {
                if (!Physics.Raycast(hit.point, r.direction, out hit))//
                    break;
            }

        }
        if (hit.transform != null)
            moveToDestination = hit.point;
    }
    return moveToDestination;
}
}



