﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class BasicCombat : MonoBehaviour {
    public Engine myRoot, targetRoot;
    public List<Engine> enemies;
    public bool atkReady;
    public NavMeshAgent myAgent;

    public float rotateSpeedWhenAtk = 8;
    float velocityRoto;
    // Use this for initialization
    void Start()
    {
        myRoot = GetComponent<Engine>();
        myAgent = GetComponent<NavMeshAgent>();
        Invoke("ReadyAction", myRoot.atkSpeed);
    }

    // Update is called once per frame
    void Update()
    {
        enemies.Clear();
        foreach (Engine detectedObject in myRoot.detected)
        {
            if (detectedObject != null)
            {
                if (detectedObject.tag == "Zombie") enemies.Add(detectedObject);
            }
        }
        if (enemies.Count > 0)
        {
            targetRoot = enemies[0];
            foreach (var enemy in enemies)
            {
                float dist1 = Vector3.Distance(transform.position, targetRoot.transform.position);

                float dist2 = Vector3.Distance(transform.position, enemy.transform.position);
                if (dist1 > dist2) targetRoot = enemy;
            }
            if (myRoot.currentState != Engine.STATE.Moving)
            {
                myRoot.ChangeState(Engine.STATE.Combat);
                if (Vector3.Distance(transform.position, targetRoot.transform.position) > myRoot.reach)
                {
                    myAgent.SetDestination(targetRoot.transform.position);
                    myAgent.Resume();
                }
                else//when in range stop and look at target
                {
                    myAgent.Stop();
                    Quaternion rotationToLookAt = Quaternion.LookRotation(targetRoot.transform.position - transform.position);
                    float rotationY = Mathf.SmoothDampAngle(transform.eulerAngles.y, rotationToLookAt.eulerAngles.y, ref velocityRoto, rotateSpeedWhenAtk * Time.deltaTime);
                    transform.eulerAngles = new Vector3(0, rotationY, 0);
                    //attack the target when ready
                    if (atkReady)
                    {
                        atkReady = false;
                        Invoke("ReadyAction", myRoot.atkSpeed);
                        //Calculate damage to make
                        int dmg = myRoot.atk + Random.Range(-myRoot.atkVar, myRoot.atkVar + 1);
                        targetRoot.TakeDamage(dmg);
                    }
                }
            }
        }
        else if (myRoot.currentState == Engine.STATE.Combat)
        {
            myRoot.ChangeState(Engine.STATE.Idle);
        }
    }
    void ReadyAction()
    {
        atkReady = true;
    }
}
